// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract BloodDonationBaseline {
    struct BloodBank {
        string name;
        string licenseId;
        string inventoryLevels;
        string timestamp;
    }

    mapping(address => BloodBank) public bloodBanks;

    function updateInventoryOnChain(
        string memory _name,
        string memory _licenseId,
        string memory _inventoryLevels,
        string memory _timestamp
    ) public {
        bloodBanks[msg.sender] = BloodBank(_name, _licenseId, _inventoryLevels, _timestamp);
    }
}