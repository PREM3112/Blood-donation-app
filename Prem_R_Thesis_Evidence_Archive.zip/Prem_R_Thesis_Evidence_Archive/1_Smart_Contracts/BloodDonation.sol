// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract BloodDonation {
    struct BloodBank {
        string ipfsCID;
        string latitude;
        string longitude;
        bool isVerified;
        bool isActive;
    }

    address public admin;
    mapping(address => BloodBank) public bloodBanks;

    event BloodBankRegistered(address indexed bankAddress, string ipfsCID);
    event BloodBankVerified(address indexed bankAddress, bool status);
    event InventoryUpdated(address indexed bankAddress, string newIpfsCID);

    modifier onlyAdmin() {
        require(msg.sender == admin, "Only admin can call this");
        _;
    }

    modifier onlyVerifiedBank() {
        require(bloodBanks[msg.sender].isVerified, "Bank must be verified");
        _;
    }

    constructor() {
        admin = msg.sender;
    }

    function registerBloodBank(string memory _ipfsCID, string memory _latitude, string memory _longitude) public {
        bloodBanks[msg.sender] = BloodBank({
            ipfsCID: _ipfsCID,
            latitude: _latitude,
            longitude: _longitude,
            isVerified: false,
            isActive: true
        });
        emit BloodBankRegistered(msg.sender, _ipfsCID);
    }

    function verifyBloodBank(address _bankAddress, bool _status) public onlyAdmin {
        require(bytes(bloodBanks[_bankAddress].ipfsCID).length > 0, "Bank not registered");
        bloodBanks[_bankAddress].isVerified = _status;
        emit BloodBankVerified(_bankAddress, _status);
    }

    function updateInventory(string memory _newIpfsCID) public onlyVerifiedBank {
        bloodBanks[msg.sender].ipfsCID = _newIpfsCID;
        emit InventoryUpdated(msg.sender, _newIpfsCID);
    }
}